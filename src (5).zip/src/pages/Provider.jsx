import { useState } from "react";
import { Building2, Search } from "lucide-react";
import ActorAvatar from "../components/common/ActorAvatar";
import DashboardLayout from "../components/layout/DashboardLayout";
import providersData from "../data/providers.json";
import "../styles/catalog.css";

const providers = providersData.items;

function Provider() {
  const [query, setQuery] = useState("");
  const filteredProviders = providers.filter((provider) =>
    `${provider.name} ${provider.type} ${provider.location}`.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <DashboardLayout>
      <section className="workspace-page">
        <header className="page-heading">
          <div>
            <p className="page-kicker">EKOSISTEM / MITRA LAYANAN</p>
            <h1>Provider</h1>
            <p>Mitra pendampingan, pelatihan, dan teknologi untuk UMKM.</p>
          </div>
          <div className="page-count"><Building2 size={17} /> {filteredProviders.length} provider</div>
        </header>

        <p className="prototype-label">{providersData.dataStatus}</p>

        <label className="catalog-search catalog-search-wide">
          <Search size={17} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cari provider, keahlian, atau wilayah" />
        </label>

        <div className="provider-grid">
          {filteredProviders.map((provider) => (
            <article className="provider-tile" key={provider.id}>
              <div className="provider-mark"><ActorAvatar assetKey={provider.imageKey} name={provider.name} icon={Building2} /></div>
              <div className="provider-title"><h2>{provider.name}</h2></div>
              <p>{provider.type}</p>
              <div className="provider-meta"><span>Wilayah</span><strong>{provider.location}</strong></div>
            </article>
          ))}
          {filteredProviders.length === 0 && <p className="empty-state">Tidak ada provider yang cocok dengan pencarian.</p>}
        </div>
      </section>
    </DashboardLayout>
  );
}

export default Provider;