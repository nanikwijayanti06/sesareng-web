import { useState } from "react";
import { GraduationCap, Search } from "lucide-react";
import ActorAvatar from "../components/common/ActorAvatar";
import DashboardLayout from "../components/layout/DashboardLayout";
import universitiesData from "../data/universities.json";
import "../styles/catalog.css";

const universities = universitiesData.items;

function University() {
  const [query, setQuery] = useState("");
  const filteredUniversities = universities.filter((university) =>
    `${university.name} ${university.location}`.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <DashboardLayout>
      <section className="workspace-page">
        <header className="page-heading">
          <div>
            <p className="page-kicker">EKOSISTEM / MITRA AKADEMIK</p>
            <h1>Perguruan Tinggi</h1>
            <p>Kolaborasi keahlian akademik untuk mendukung produktivitas daerah.</p>
          </div>
          <div className="page-count"><GraduationCap size={18} /> {filteredUniversities.length} mitra</div>
        </header>

        <p className="prototype-label">{universitiesData.dataStatus}</p>

        <label className="catalog-search catalog-search-wide">
          <Search size={17} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cari institusi, keahlian, atau wilayah" />
        </label>

        <div className="university-list">
            {filteredUniversities.map((university) => (
            <article className="university-row" key={university.id}>
              <ActorAvatar assetKey={university.imageKey} className="university-monogram" name={university.name} />
              <div className="university-info"><h2>{university.name}</h2><p>Mitra perguruan tinggi</p></div>
              <div className="university-partners"><strong>{university.shortName}</strong><span>Institusi</span></div>
              <span className="university-area">{university.location}</span>
            </article>
          ))}
          {filteredUniversities.length === 0 && <p className="empty-state">Tidak ada perguruan tinggi yang cocok dengan pencarian.</p>}
        </div>
      </section>
    </DashboardLayout>
  );
}

export default University;