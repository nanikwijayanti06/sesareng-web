import { useState } from "react";
import { Search, Store } from "lucide-react";
import ActorAvatar from "../components/common/ActorAvatar";
import DashboardLayout from "../components/layout/DashboardLayout";
import umkmData from "../data/umkm.json";
import "../styles/catalog.css";

const businesses = umkmData.items;

function Umkm() {
  const [query, setQuery] = useState("");
  const [stage, setStage] = useState("Semua tahap");
  const visibleBusinesses = businesses.filter((business) => {
    const matchesQuery = `${business.name} ${business.diagnoseProfile} ${business.location}`
      .toLowerCase()
      .includes(query.toLowerCase());
    return matchesQuery && (stage === "Semua tahap" || business.stage === stage);
  });

  return (
    <DashboardLayout>
      <section className="workspace-page">
        <header className="page-heading">
          <div>
            <p className="page-kicker">EKOSISTEM / PELAKU USAHA</p>
            <h1>UMKM</h1>
            <p>Daftar usaha dan perkembangan kesiapan produktivitas.</p>
          </div>
          <div className="page-count"><Store size={17} /> {visibleBusinesses.length} UMKM</div>
        </header>

        <p className="prototype-label">{umkmData.dataStatus}</p>

        <div className="catalog-toolbar">
          <label className="catalog-search">
            <Search size={17} />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cari nama, sektor, atau wilayah" />
          </label>
          <select aria-label="Filter tahap ARPI" value={stage} onChange={(event) => setStage(event.target.value)}>
            {["Semua tahap", "Diagnose", "Match", "Enable", "Adopt", "Verify", "Adapt"].map((item) => <option key={item}>{item}</option>)}
          </select>
        </div>

        <div className="catalog-table-wrap">
          <table className="catalog-table">
            <thead><tr><th>Nama UMKM</th><th>Profil Diagnose</th><th>Wilayah</th><th>Tahap ARPI</th></tr></thead>
            <tbody>
              {visibleBusinesses.map((business) => (
                <tr key={business.id}>
                  <td><span className="catalog-actor"><ActorAvatar assetKey={business.imageKey} name={business.name} /><strong>{business.name}</strong></span></td>
                  <td>{business.diagnoseProfile}</td>
                  <td>{business.location}</td>
                  <td><span className="stage-tag">{business.stage}</span></td>
                </tr>
              ))}
              {visibleBusinesses.length === 0 && <tr><td className="empty-state" colSpan="4">Tidak ada UMKM yang cocok dengan pencarian.</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </DashboardLayout>
  );
}

export default Umkm;