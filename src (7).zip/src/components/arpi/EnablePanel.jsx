import ActorAvatar from "../common/ActorAvatar";
import "../../styles/arpi.css";

const formatCurrency = (value) => `Rp ${Number(value).toLocaleString("id-ID")}`;

function EnablePanel({ records }) {
  const allocationTotal = records.reduce((total, record) => total + (record.enable.voucherAllocation ?? 0), 0);
  const usedTotal = records.reduce((total, record) => total + (record.enable.voucherUsed ?? 0), 0);
  const trainingCount = records.filter((record) => record.enable.trainingProgram).length;

  return (
    <section className="arpi-panel" role="tabpanel" aria-label="Enable">
      <div className="arpi-panel-intro"><div><h2>Enable: sumber daya dan kapasitas</h2><p>Productivity Voucher membantu kendala finansial; targeted training menutup capability gap.</p></div><span className="prototype-chip">Data simulasi/prototipe</span></div>
      <div className="arpi-summary-grid arpi-enable-summaries">
        <article className="arpi-summary-card"><span>Productivity Voucher</span><strong>{formatCurrency(usedTotal)} / {formatCurrency(allocationTotal)}</strong><small>Alokasi dan penggunaan contoh</small></article>
        <article className="arpi-summary-card arpi-summary-teal"><span>Targeted Training</span><strong>{trainingCount} program</strong><small>Program pengembangan kapabilitas</small></article>
      </div>
      <div className="arpi-record-list">
        {records.map((record) => {
          const enable = record.enable;
          const progress = enable.voucherAllocation > 0
            ? Math.min(100, Math.round((enable.voucherUsed / enable.voucherAllocation) * 100))
            : 0;
          return (
            <article className="arpi-card arpi-enable-card" key={record.id}>
              <div className="arpi-record-main">
                <ActorAvatar assetKey={record.imageKey} name={record.name} />
                <div className="arpi-record-identity"><strong>{record.name}</strong><span>{record.location} · {record.primaryBottleneck}</span></div>
                <span className={`status-badge ${enable.status === "Selesai" ? "status-success" : enable.status === "Berjalan" ? "status-warning" : "status-neutral"}`}>{enable.status}</span>
              </div>
              <div className="arpi-enable-data">
                <div><span>Voucher allocation</span><strong>{formatCurrency(enable.voucherAllocation)}</strong></div>
                <div><span>Voucher used</span><strong>{formatCurrency(enable.voucherUsed)}</strong></div>
                <div><span>Training program</span><strong>{enable.trainingProgram}</strong></div>
                <div><span>Capability gap</span><strong>{enable.capabilityGap}</strong></div>
                <div><span>Training provider</span><strong>{enable.trainingProvider?.name ?? "Belum ditetapkan"}</strong></div>
              </div>
              <div className="arpi-progress-block">
                <div><span>Realisasi voucher</span><strong>{progress}%</strong></div>
                <div className="arpi-progress-bar" role="progressbar" aria-label={`Realisasi voucher ${record.name}`} aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}><span style={{ width: `${progress}%` }} /></div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

export default EnablePanel;