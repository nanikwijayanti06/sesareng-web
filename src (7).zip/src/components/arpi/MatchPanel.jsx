import { useMemo, useState } from "react";
import { RotateCcw, Search } from "lucide-react";
import ActorAvatar from "../common/ActorAvatar";
import { filterByBottleneck, filterByProvider, filterBySearch, filterByStatus, resetFilters } from "../../logic/filterLogic";
import InterventionCard from "./InterventionCard";
import "../../styles/arpi.css";

const initialFilters = { search: "", bottleneck: "", appropriateness: "", providerId: "", status: "" };

function MatchPanel({ records, providers }) {
  const [filters, setFilters] = useState(initialFilters);
  const bottlenecks = [...new Set(records.map((record) => record.primaryBottleneck))];
  const visibleRecords = useMemo(() => {
    let filtered = filterBySearch(records, filters.search, ["name", "primaryBottleneck", "intervention.name", "match.provider.name", "match.university.name"]);
    filtered = filterByBottleneck(filtered, filters.bottleneck, ["primaryBottleneck"]);
    filtered = filterByProvider(filtered, filters.providerId, ["match.provider.id"]);
    filtered = filterByStatus(filtered, filters.status, ["match.status"]);
    if (filters.appropriateness) filtered = filtered.filter((record) => record.match.aiAppropriateness === filters.appropriateness);
    return filtered;
  }, [records, filters]);
  const updateFilter = (key, value) => setFilters((current) => ({ ...current, [key]: value }));

  return (
    <section className="arpi-panel" role="tabpanel" aria-label="Match">
      <div className="arpi-panel-intro"><div><h2>Match & AI Appropriateness</h2><p>Cocokkan bottleneck dengan intervensi, provider, dan mitra akademik. AI bukan pilihan wajib.</p></div><span className="prototype-chip">Data simulasi/prototipe</span></div>
      <div className="arpi-filter-row arpi-filter-row-match">
        <label className="arpi-search"><Search size={16} /><input aria-label="Cari intervensi" onChange={(event) => updateFilter("search", event.target.value)} placeholder="Cari UMKM/intervensi" value={filters.search} /></label>
        <select aria-label="Filter bottleneck" onChange={(event) => updateFilter("bottleneck", event.target.value)} value={filters.bottleneck}><option value="">Semua bottleneck</option>{bottlenecks.map((item) => <option key={item}>{item}</option>)}</select>
        <select aria-label="AI Appropriateness" onChange={(event) => updateFilter("appropriateness", event.target.value)} value={filters.appropriateness}><option value="">Semua appropriateness</option><option>Tinggi</option><option>Sedang</option><option>Rendah</option><option>AI tidak diperlukan</option></select>
        <select aria-label="Filter provider" onChange={(event) => updateFilter("providerId", event.target.value)} value={filters.providerId}><option value="">Semua provider</option>{providers.map((provider) => <option key={provider.id} value={provider.id}>{provider.name}</option>)}</select>
        <select aria-label="Status match" onChange={(event) => updateFilter("status", event.target.value)} value={filters.status}><option value="">Semua status</option><option>Recommended</option><option>Review</option><option>Not Suitable</option></select>
        <button className="arpi-reset" onClick={() => setFilters(resetFilters(initialFilters))} type="button"><RotateCcw size={14} /> Reset</button>
      </div>

      <div className="arpi-match-list">
        {visibleRecords.map((record) => (
          <InterventionCard
            className="arpi-match-card"
            eyebrow={`${record.name} · ${record.primaryBottleneck}`}
            key={record.id}
            title={record.intervention?.name ?? "Belum direkomendasikan"}
          >
            <div className="arpi-match-layout">
              <div className="arpi-match-actor"><ActorAvatar assetKey={record.imageKey} name={record.name} /><div><strong>{record.name}</strong><span>{record.location}</span></div></div>
              <div className="arpi-match-detail"><span>AI Appropriateness</span><strong>{record.match.aiAppropriateness}</strong></div>
              <div className="arpi-match-partners"><span><small>Provider</small><strong>{record.match.provider?.name ?? "Belum dipilih"}</strong></span><span><small>Perguruan tinggi</small><strong>{record.match.university?.name ?? "Belum dipilih"}</strong></span></div>
              <span className={`status-badge ${record.match.status === "Recommended" ? "status-success" : record.match.status === "Not Suitable" ? "status-danger" : "status-warning"}`}>{record.match.status}</span>
            </div>
          </InterventionCard>
        ))}
        {visibleRecords.length === 0 && <p className="arpi-empty-state">Tidak ada rekomendasi sesuai filter.</p>}
      </div>
    </section>
  );
}

export default MatchPanel;