import { CheckCircle2, ClipboardCheck } from "lucide-react";
import { calculateChangePercentage, getVerifyStatus } from "../../logic/monitoringLogic";
import ActorAvatar from "../common/ActorAvatar";
import "../../styles/arpi.css";

function formatMetric(value, unit) {
  const formatted = Number(value).toLocaleString("id-ID", { maximumFractionDigits: 2 });
  return unit === "index" ? formatted : `${formatted} ${unit}`;
}

function VerifyPanel({ records }) {
  return (
    <section className="arpi-panel" role="tabpanel" aria-label="Verify">
      <div className="arpi-panel-intro"><div><h2>Outcome Measurement</h2><p>Bandingkan baseline, hasil aktual, dan target untuk setiap indikator produktivitas.</p></div><span className="prototype-chip">Data simulasi/prototipe</span></div>
      <div className="arpi-verification-list">
        {records.map((record) => (
          <article className="arpi-card" key={record.id}>
            <div className="arpi-record-main">
              <ActorAvatar assetKey={record.imageKey} name={record.name} />
              <div className="arpi-record-identity"><strong>{record.name}</strong><span>Before-after · target vs actual</span></div>
              <span className={`status-badge ${record.verify.overallStatus === "Target Tercapai" ? "status-success" : record.verify.overallStatus === "Perlu Review" ? "status-warning" : "status-danger"}`}><CheckCircle2 size={13} />{record.verify.overallStatus}</span>
            </div>
            <div className="verification-grid">
              {record.verify.metrics.map((metric) => {
                const status = getVerifyStatus(metric.actual, metric.target, metric.lowerIsBetter);
                const change = calculateChangePercentage(metric.before, metric.actual);
                return (
                  <div className="verification-metric" key={metric.key}>
                    <div className="verification-metric-heading"><strong>{metric.label}</strong><span className={`status-badge ${status === "Target Tercapai" ? "status-success" : status === "Perlu Review" ? "status-warning" : "status-danger"}`}>{status}</span></div>
                    <div className="verification-values">
                      <span><small>Before</small><strong>{formatMetric(metric.before, metric.unit)}</strong></span>
                      <span aria-hidden="true">→</span>
                      <span><small>After</small><strong>{formatMetric(metric.after, metric.unit)}</strong></span>
                    </div>
                    <div className="verification-target"><span>Target <strong>{formatMetric(metric.target, metric.unit)}</strong></span><span>Actual <strong>{formatMetric(metric.actual, metric.unit)}</strong></span></div>
                    <small className="verification-change">Perubahan {change > 0 ? "+" : ""}{change}%</small>
                  </div>
                );
              })}
            </div>
            <div className="verification-footnote"><ClipboardCheck size={14} /> Pengukuran contoh untuk evaluasi prototipe.</div>
          </article>
        ))}
      </div>
    </section>
  );
}

export default VerifyPanel;