import { useState } from "react";
import { RefreshCw } from "lucide-react";
import { getAdaptDecision } from "../../logic/monitoringLogic";
import ActorAvatar from "../common/ActorAvatar";
import "../../styles/arpi.css";

const decisions = ["Continue", "Adjust", "Replace", "Scale"];

function AdaptPanel({ records }) {
  const [decisionOverrides, setDecisionOverrides] = useState({});

  return (
    <section className="arpi-panel" role="tabpanel" aria-label="Adapt">
      <div className="arpi-panel-intro"><div><h2>Adapt & Follow-up</h2><p>Keputusan awal berasal dari hasil Verify dan aturan monitoring; petugas dapat mengubahnya.</p></div><span className="prototype-chip">Data simulasi/prototipe</span></div>
      <div className="arpi-adapt-list">
        {records.map((record) => {
          const adapt = record.adapt;
          const suggestedDecision = getAdaptDecision({
            verifyStatus: record.verify.overallStatus,
            eligibleToScale: adapt.eligibleToScale,
            mismatch: record.verify.overallStatus === "Di Bawah Target",
          });
          const decision = decisionOverrides[record.id] ?? suggestedDecision;
          return (
            <article className="arpi-card arpi-adapt-card" key={record.id}>
              <div className="arpi-record-main">
                <ActorAvatar assetKey={record.imageKey} name={record.name} />
                <div className="arpi-record-identity"><strong>{record.name}</strong><span>Verify: {record.verify.overallStatus}</span></div>
                <span className="status-badge status-neutral">Rekomendasi: {suggestedDecision}</span>
              </div>
              <div className="adapt-decision">
                <label>
                  <span>Keputusan adaptasi</span>
                  <select aria-label={`Keputusan adaptasi ${record.name}`} onChange={(event) => setDecisionOverrides((current) => ({ ...current, [record.id]: event.target.value }))} value={decision}>
                    {decisions.map((item) => <option key={item}>{item}</option>)}
                  </select>
                </label>
                <span className="status-badge status-info"><RefreshCw size={13} />{decision}</span>
              </div>
              <p className="adapt-reason">{adapt.reason}</p>
              <div className="arpi-adapt-meta">
                <div><span>Next action</span><strong>{adapt.nextAction}</strong></div>
                <div><span>Responsible actor</span><strong>{adapt.responsibleActor}</strong></div>
                <div><span>Follow-up status</span><strong>{adapt.followUpStatus}</strong></div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

export default AdaptPanel;