import { NavLink, useNavigate } from "react-router-dom";
import { logoutUser } from "../../logic/auth";

function Sidebar({ isOpen, onClose }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    logoutUser();
    navigate("/login");
  };

  const menuItems = [
    {
      section: "UTAMA",
      items: [
        {
          name: "Dashboard",
          path: "/dashboard",
          icon: "⌂",
        },
      ],
    },
    {
      section: "EKOSISTEM",
      items: [
        {
          name: "UMKM",
          path: "/umkm",
          icon: "▦",
        },
        {
          name: "Provider",
          path: "/provider",
          icon: "◈",
        },
        {
          name: "Perguruan Tinggi",
          path: "/universitas",
          icon: "◇",
        },
        {
          name: "Peta Ekosistem",
          path: "/map",
          icon: "⌖",
        },
      ],
    },
    {
      section: "PROGRAM",
      items: [
        {
          name: "Program ARPI",
          path: "/arpi",
          icon: "◎",
        },
      ],
    },
  ];

  return (
    <>
      {isOpen && (
        <div
          className="sidebar-overlay"
          onClick={onClose}
        />
      )}

      <aside
        className={`dashboard-sidebar ${
          isOpen ? "sidebar-open" : ""
        }`}
      >
        <div className="sidebar-brand">
          <div className="sidebar-logo">
            <span></span>
          </div>

          <div>
            <strong>SESARENG</strong>
            <small>Government Portal</small>
          </div>
        </div>

        <nav className="sidebar-nav">
          {menuItems.map((group) => (
            <div
              className="sidebar-group"
              key={group.section}
            >
              <p className="sidebar-section-title">
                {group.section}
              </p>

              {group.items.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  onClick={onClose}
                  className={({ isActive }) =>
                    isActive
                      ? "sidebar-link active"
                      : "sidebar-link"
                  }
                >
                  <span className="sidebar-icon">
                    {item.icon}
                  </span>

                  <span>{item.name}</span>
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="sidebar-help">
            <div className="help-icon">?</div>

            <div>
              <strong>Pusat Bantuan</strong>
              <span>Panduan penggunaan</span>
            </div>
          </div>

          <button
            className="logout-button"
            onClick={handleLogout}
          >
            <span>↪</span>
            Keluar
          </button>
        </div>
      </aside>
    </>
  );
}

export default Sidebar;