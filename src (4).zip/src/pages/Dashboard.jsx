import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Activity,
  ArrowRight,
  Building2,
  CheckCircle2,
  ChevronRight,
  GraduationCap,
  MapPin,
  MapPinned,
  Search,
  Store,
  Users,
  Workflow,
} from "lucide-react";
import {
  CircleMarker,
  MapContainer,
  Popup,
  TileLayer,
} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import DashboardLayout from "../components/layout/DashboardLayout";
import "../styles/dashboard.css";

const actors = [
  {
    name: "Hierro Watch",
    type: "UMKM",
    detail: "Targeted AI",
    diagnoseProfile: "Targeted AI",
    region: "Kota Yogyakarta",
    stage: "Match",
    position: [-7.7972, 110.3705],
  },
  {
    name: "Bakpia Kencana",
    type: "UMKM",
    detail: "Basic AI",
    diagnoseProfile: "Basic AI",
    region: "Sleman",
    stage: "Enable",
    position: [-7.731, 110.355],
  },
  {
    name: "Batik Astoetik",
    type: "UMKM",
    detail: "Advanced AI",
    diagnoseProfile: "Advanced AI",
    region: "Bantul",
    stage: "Adopt",
    position: [-7.888, 110.328],
  },
  {
    name: "UNY",
    type: "Perguruan Tinggi",
    detail: "Mitra akademik",
    region: "Sleman",
    stage: "Match",
    position: [-7.772, 110.388],
  },
  {
    name: "UGM",
    type: "Perguruan Tinggi",
    detail: "Mitra akademik",
    region: "Sleman",
    stage: "Enable",
    position: [-7.771, 110.377],
  },
  {
    name: "UIN",
    type: "Perguruan Tinggi",
    detail: "Mitra akademik",
    region: "Sleman",
    stage: "Diagnose",
    position: [-7.783, 110.394],
  },
  {
    name: "UII",
    type: "Perguruan Tinggi",
    detail: "Mitra akademik",
    region: "Sleman",
    stage: "Verify",
    position: [-7.687, 110.414],
  },
  {
    name: "Jogja Media Training",
    type: "Provider",
    detail: "Training Provider",
    region: "Kota Yogyakarta",
    stage: "Enable",
    position: [-7.801, 110.361],
  },
  {
    name: "Gmedia",
    type: "Provider",
    detail: "Technology Provider",
    region: "Sleman",
    stage: "Match",
    position: [-7.756, 110.376],
  },
];

const regions = [
  "Kota Yogyakarta",
  "Sleman",
  "Bantul",
  "Kulon Progo",
  "Gunungkidul",
];

const stages = ["Diagnose", "Match", "Enable", "Adopt", "Verify", "Adapt"];

const stageCounts = [
  { name: "Diagnose", count: 42 },
  { name: "Match", count: 31 },
  { name: "Enable", count: 24 },
  { name: "Adopt", count: 18 },
  { name: "Verify", count: 12 },
  { name: "Adapt", count: 8 },
];

const bottlenecks = [
  { name: "Pemasaran digital", count: 18, percent: 82 },
  { name: "Pengelolaan stok", count: 14, percent: 64 },
  { name: "Kapasitas SDM", count: 11, percent: 50 },
  { name: "Kualitas produksi", count: 8, percent: 36 },
];

const activities = [
  { title: "Diagnose selesai", text: "Hierro Watch menyelesaikan asesmen awal.", time: "10 menit lalu", icon: CheckCircle2 },
  { title: "Provider terhubung", text: "Jogja Media Training terhubung ke Bakpia Kencana.", time: "1 jam lalu", icon: Users },
  { title: "Tahap Enable dimulai", text: "Dukungan adopsi teknologi untuk Batik Astoetik.", time: "3 jam lalu", icon: Workflow },
];

const markerColors = {
  UMKM: "#2463eb",
  Provider: "#0c766e",
  "Perguruan Tinggi": "#52667f",
};

const previews = [
  {
    title: "UMKM",
    count: "3 pelaku usaha",
    route: "/umkm",
    icon: Store,
    items: ["Hierro Watch", "Bakpia Kencana", "Batik Astoetik"],
  },
  {
    title: "Perguruan Tinggi",
    count: "4 mitra akademik",
    route: "/universitas",
    icon: GraduationCap,
    items: ["UNY", "UGM", "UIN", "UII"],
  },
  {
    title: "Provider",
    count: "2 mitra layanan",
    route: "/provider",
    icon: Building2,
    items: ["Jogja Media Training", "Gmedia"],
  },
];

function Dashboard() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [region, setRegion] = useState("");
  const [actorType, setActorType] = useState("");
  const [stage, setStage] = useState("");
  const [diagnoseProfile, setDiagnoseProfile] = useState("");

  const filteredActors = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("id");

    return actors.filter((actor) => {
      const matchesSearch = !query || [
        actor.name,
        actor.type,
        actor.detail,
        actor.region,
        actor.stage,
      ].some((value) => value.toLocaleLowerCase("id").includes(query));

      return matchesSearch
        && (!region || actor.region === region)
        && (!actorType || actor.type === actorType)
        && (!stage || actor.stage === stage)
        && (!diagnoseProfile || actor.diagnoseProfile === diagnoseProfile);
    });
  }, [search, region, actorType, stage, diagnoseProfile]);

  const metrics = [
    { label: "Total UMKM", value: "3", note: "Pelaku usaha terdata", icon: Store, route: "/umkm" },
    { label: "Provider", value: "2", note: "Mitra layanan aktif", icon: Building2, route: "/provider" },
    { label: "Perguruan Tinggi", value: "4", note: "Mitra akademik", icon: GraduationCap, route: "/universitas" },
    { label: "Intervensi Aktif", value: "4", note: "Dalam tahap Enable dan Adopt", icon: Activity, route: "/arpi" },
  ];

  const resetFilters = () => {
    setSearch("");
    setRegion("");
    setActorType("");
    setStage("");
    setDiagnoseProfile("");
  };

  return (
    <DashboardLayout>
      <div className="dashboard-page">
        <header className="dashboard-heading">
          <div>
            <p className="dashboard-kicker">KOORDINASI EKOSISTEM DAERAH</p>
            <h1>Dashboard Sesareng</h1>
            <p className="dashboard-subtitle">Regional AI Hub - Daerah Istimewa Yogyakarta</p>
          </div>
          <button className="dashboard-map-link" onClick={() => navigate("/map")} type="button">
            <MapPinned size={17} />
            Buka peta penuh
            <ArrowRight size={15} />
          </button>
        </header>

        <section className="dashboard-metrics" aria-label="Ringkasan ekosistem">
          {metrics.map(({ label, value, note, icon: Icon, route }) => (
            <button className="dashboard-metric" key={label} onClick={() => navigate(route)} type="button">
              <span className="metric-icon"><Icon size={19} /></span>
              <span className="metric-copy">
                <span className="metric-label">{label}</span>
                <strong>{value}</strong>
                <span className="metric-note">{note}</span>
              </span>
              <ChevronRight className="metric-chevron" size={17} />
            </button>
          ))}
        </section>

        <section className="dashboard-panel ecosystem-panel">
          <div className="panel-heading ecosystem-heading">
            <div>
              <p className="panel-kicker">SEBARAN AKTOR</p>
              <h2>Peta Ekosistem</h2>
              <p className="panel-description">Sebaran pelaku usaha dan mitra Regional AI Hub di DIY.</p>
            </div>
            <div className="map-legend" aria-label="Legenda peta">
              {Object.entries(markerColors).map(([type, color]) => (
                <span key={type}><i style={{ backgroundColor: color }} />{type}</span>
              ))}
            </div>
          </div>

          <div className="ecosystem-filters">
            <label className="filter-search">
              <span>Cari aktor</span>
              <div className="filter-input-wrap">
                <Search size={16} />
                <input
                  aria-label="Cari aktor"
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Nama, layanan, wilayah..."
                  value={search}
                />
              </div>
            </label>
            <label>
              <span>Wilayah</span>
              <select aria-label="Filter wilayah" onChange={(event) => setRegion(event.target.value)} value={region}>
                <option value="">Semua wilayah</option>
                {regions.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </label>
            <label>
              <span>Jenis aktor</span>
              <select aria-label="Filter jenis aktor" onChange={(event) => setActorType(event.target.value)} value={actorType}>
                <option value="">Semua jenis</option>
                <option value="UMKM">UMKM</option>
                <option value="Provider">Provider</option>
                <option value="Perguruan Tinggi">Perguruan Tinggi</option>
              </select>
            </label>
            <label>
              <span>Tahap ARPI</span>
              <select aria-label="Filter tahap ARPI" onChange={(event) => setStage(event.target.value)} value={stage}>
                <option value="">Semua tahap</option>
                {stages.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </label>
            <label>
              <span>Profil Diagnose</span>
              <select aria-label="Filter profil Diagnose" onChange={(event) => setDiagnoseProfile(event.target.value)} value={diagnoseProfile}>
                <option value="">Semua profil</option>
                <option value="Basic AI">Basic AI</option>
                <option value="Targeted AI">Targeted AI</option>
                <option value="Advanced AI">Advanced AI</option>
              </select>
            </label>
            <button className="filter-reset" onClick={resetFilters} type="button">Reset</button>
          </div>

          <div className="map-result-count" aria-live="polite">
            Menampilkan <strong>{filteredActors.length}</strong> dari {actors.length} aktor
          </div>
          <div className="ecosystem-map-frame">
            <MapContainer
              center={[-7.83, 110.38]}
              className="ecosystem-map"
              scrollWheelZoom={false}
              zoom={10}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              {filteredActors.map((actor) => (
                <CircleMarker
                  center={actor.position}
                  fillColor={markerColors[actor.type]}
                  fillOpacity={0.92}
                  key={actor.name}
                  pathOptions={{ color: "#ffffff", weight: 2 }}
                  radius={9}
                  stroke
                >
                  <Popup>
                    <div className="map-popup">
                      <strong>{actor.name}</strong>
                      <span>{actor.type} · {actor.detail}</span>
                      <span>{actor.region} · {actor.stage}</span>
                    </div>
                  </Popup>
                </CircleMarker>
              ))}
            </MapContainer>
            {filteredActors.length === 0 && (
              <div className="map-empty-state">Tidak ada aktor yang cocok dengan filter.</div>
            )}
          </div>
        </section>

        <section className="dashboard-lower-grid">
          <article className="dashboard-panel pipeline-panel">
            <div className="panel-heading">
              <div>
                <p className="panel-kicker">PROGRAM</p>
                <h2>ARPI Pipeline</h2>
              </div>
              <button className="panel-link" onClick={() => navigate("/arpi")} type="button">Lihat program <ArrowRight size={14} /></button>
            </div>
            <div className="pipeline-list">
              {stageCounts.map((item, index) => (
                <button className="pipeline-stage" key={item.name} onClick={() => { setStage(item.name); window.scrollTo({ top: 0, behavior: "smooth" }); }} type="button">
                  <span className={`pipeline-number${index < 2 ? " is-active" : ""}`}>{String(index + 1).padStart(2, "0")}</span>
                  <span className="pipeline-name">{item.name}</span>
                  <strong>{item.count}</strong>
                  <ChevronRight size={15} />
                </button>
              ))}
            </div>
          </article>

          <article className="dashboard-panel bottleneck-panel">
            <div className="panel-heading">
              <div>
                <p className="panel-kicker">DIAGNOSE</p>
                <h2>Productivity Bottleneck</h2>
              </div>
              <button className="panel-link" onClick={() => navigate("/umkm")} type="button">Detail <ArrowRight size={14} /></button>
            </div>
            <div className="bottleneck-list">
              {bottlenecks.map((item) => (
                <div className="bottleneck-item" key={item.name}>
                  <div className="bottleneck-label"><span>{item.name}</span><strong>{item.count} UMKM</strong></div>
                  <div className="bottleneck-track"><span style={{ width: `${item.percent}%` }} /></div>
                </div>
              ))}
            </div>
          </article>

          <article className="dashboard-panel activity-panel">
            <div className="panel-heading">
              <div>
                <p className="panel-kicker">PEMANTAUAN</p>
                <h2>Aktivitas terbaru</h2>
              </div>
              <Activity size={18} className="activity-heading-icon" />
            </div>
            <div className="activity-list">
              {activities.map(({ title, text, time, icon: Icon }) => (
                <div className="activity-row" key={title}>
                  <span className="activity-icon"><Icon size={16} /></span>
                  <div><strong>{title}</strong><p>{text}</p><time>{time}</time></div>
                </div>
              ))}
            </div>
          </article>
        </section>

        <section className="directory-section">
          <div className="directory-heading">
            <div>
              <p className="panel-kicker">DIREKTORI EKOSISTEM</p>
              <h2>Aktor Regional AI Hub</h2>
            </div>
            <button className="panel-link" onClick={() => navigate("/map")} type="button">Jelajahi ekosistem <ArrowRight size={14} /></button>
          </div>
          <div className="directory-grid">
            {previews.map(({ title, count, route, icon: Icon, items }) => (
              <button className="directory-card" key={title} onClick={() => navigate(route)} type="button">
                <span className="directory-icon"><Icon size={19} /></span>
                <span className="directory-card-heading"><strong>{title}</strong><small>{count}</small></span>
                <ChevronRight size={17} />
                <span className="directory-items">{items.map((name) => <span key={name}>{name}</span>)}</span>
                <span className="directory-action">Buka direktori <ArrowRight size={14} /></span>
              </button>
            ))}
          </div>
        </section>
        <footer className="dashboard-footer"><MapPin size={14} /> Daerah Istimewa Yogyakarta <span>•</span> Data contoh untuk koordinasi Regional AI Hub</footer>
      </div>
    </DashboardLayout>
  );
}

export default Dashboard;
